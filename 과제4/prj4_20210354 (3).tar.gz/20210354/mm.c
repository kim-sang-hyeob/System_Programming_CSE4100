/*
 * mm-efree.c - Implementation of malloc using an explicit free list
 */

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <unistd.h>
#include <string.h>

#include "mm.h"
#include "memlib.h"

/*********************************************************
 * NOTE TO STUDENTS: Before you do anything else, please
 * provide your information in the following struct.
 ********************************************************/
team_t team = {
    /* Team name */
    "20210354",
    /* First member's full name */
    "sanghyeop kim", 
    /* First member's email address */
    "fgd25@sogang.ac.kr",
};

/* single word (4) or double word (8) alignment */
#define ALIGNMENT 8
#define ALIGN(size) (((size) + (ALIGNMENT-1)) & ~0x7)
#define SIZE_T_SIZE (ALIGN(sizeof(size_t)))

#define NEXT_FIT

/* Basic constants and macros */
#define WSIZE       4       
#define DSIZE       8       
#define CHUNKSIZE  (1<<12)  

#define MAX(x, y) ((x) > (y)? (x) : (y))

#define PACK(size, alloc)  ((size) | (alloc))

#define GET(p)       (*(unsigned int *)(p))
#define PUT(p, val)  (*(unsigned int *)(p) = (val))

#define GET_SIZE(p)  (GET(p) & ~0x7)
#define GET_ALLOC(p) (GET(p) & 0x1)

#define HDRP(bp)       ((char *)(bp) - WSIZE)
#define FTRP(bp)       ((char *)(bp) + GET_SIZE(HDRP(bp)) - DSIZE)

#define NEXT_BLKP(bp)  ((char *)(bp) + GET_SIZE(((char *)(bp) - WSIZE)))
#define PREV_BLKP(bp)  ((char *)(bp) - GET_SIZE(((char *)(bp) - DSIZE)))

/*매크로 추가*/
#define NEXT_NODE(ptr) (*(char **)(ptr))
#define PREV_NODE(ptr) (*(char **)(PREV_P(ptr)))

#define SET_P(p, ptr) (*(unsigned int *)(p) = (unsigned int)(ptr))
#define NEXT_P(ptr) ((char *)(ptr))
#define PREV_P(ptr) ((char *)(ptr) + WSIZE)

/* Global variables */
static char *heap_listp = 0;  

#define LISTNUM 10
static void *seg0 = NULL;  
static void *seg1 = NULL;   
static void *seg2 = NULL;   
static void *seg3 = NULL;  
static void *seg4 = NULL;   
static void *seg5 = NULL;   
static void *seg6 = NULL;   
static void *seg7 = NULL;   
static void *seg8 = NULL;   
static void *seg9 = NULL;   


static void *extend_heap(size_t words);
static void *find_fit(size_t asize);
static void *coalesce(void *bp);
static void *place(void *bp, size_t asize);


static void delete(void *bp);
static void add(void *bp, size_t size);
static int get_list(size_t size);
static void **get_seg_head(int idx);

static void **get_seg_head(int idx) {
    switch (idx) {
        case 0:  return &seg0;
        case 1:  return &seg1;
        case 2:  return &seg2;
        case 3:  return &seg3;
        case 4:  return &seg4;
        case 5:  return &seg5;
        case 6:  return &seg6;
        case 7:  return &seg7;
        case 8:  return &seg8;
        case 9:  return &seg9;
        default: return &seg9;
    }
}

int mm_init(void) 
{
    // 초기화 안해주면 error
    seg0 = seg1 = seg2 = seg3 = seg4 = seg5 = seg6 = seg7 = seg8 = seg9 = NULL;
    
    if ((heap_listp = mem_sbrk(4*WSIZE)) == (void *)-1)
        return -1;
        
    PUT(heap_listp, 0);                          
    PUT(heap_listp + (1*WSIZE), PACK(DSIZE, 1)); 
    PUT(heap_listp + (2*WSIZE), PACK(DSIZE, 1)); 
    PUT(heap_listp + (3*WSIZE), PACK(0, 1));     
    heap_listp += (2*WSIZE);
    
    if(extend_heap(8)==NULL) return -1; // tricky point -> 이걸 하면 점수가 유의미하게 +@2 점정도오른다 

    if (extend_heap(CHUNKSIZE/WSIZE) == NULL) 
        return -1;
    return 0;
}

void *mm_malloc(size_t size) 
{
    size_t asize;      
    size_t extendsize; 
    char *bp;      

    if (size <= DSIZE)
        asize = 2*DSIZE;
    else
        asize = DSIZE * ((size + (DSIZE) + (DSIZE-1)) / DSIZE);

    if ((bp = find_fit(asize)) != NULL) {
        place(bp, asize);
        return bp;
    }
    
    extendsize = MAX(asize, CHUNKSIZE);
    if ((bp = extend_heap(extendsize/WSIZE)) == NULL)  
        return NULL;
    
    place(bp, asize);
    return bp;
} 

static void *extend_heap(size_t words) 
{
    char *bp;
    size_t size;

    size = (words % 2) ? (words+1) * WSIZE : words * WSIZE;
    if ((long)(bp = mem_sbrk(size)) == -1)  
        return NULL;

    PUT(HDRP(bp), PACK(size, 0));         
    PUT(FTRP(bp), PACK(size, 0));         
    PUT(HDRP(NEXT_BLKP(bp)), PACK(0, 1)); 

    add(bp, size); // 새로 생긴 블럭 추가 해야함ㅁ

    return coalesce(bp);
}

void mm_free(void *bp)
{
    if (bp == 0) 
        return;

    size_t size = GET_SIZE(HDRP(bp));
    if (heap_listp == 0){
        mm_init();
    }

    PUT(HDRP(bp), PACK(size, 0));
    PUT(FTRP(bp), PACK(size, 0));

    add(bp, size);  // free list 에 추가 

    coalesce(bp);
}

// case 별로 처리 다르게 해주어야 함 -> prev next free node 처리
static void *coalesce(void *bp) 
{
    size_t next_alloc = GET_ALLOC(HDRP(NEXT_BLKP(bp)));
    size_t size = GET_SIZE(HDRP(bp));
    size_t prev_alloc = GET_ALLOC(FTRP(PREV_BLKP(bp)));

    if (prev_alloc && next_alloc) { 
        /*case 1 */           
        return bp;
    }
    else if (prev_alloc && !next_alloc) {     
        /*case 2 */  
        delete(bp);
        delete(NEXT_BLKP(bp)); 
        size += GET_SIZE(HDRP(NEXT_BLKP(bp)));
        PUT(HDRP(bp), PACK(size, 0));
        PUT(FTRP(bp), PACK(size, 0));
    }
    else if (!prev_alloc && next_alloc) {     
        /*case 3*/  
        delete(bp);
        delete(PREV_BLKP(bp));
        size += GET_SIZE(HDRP(PREV_BLKP(bp)));
        PUT(FTRP(bp), PACK(size, 0));
        PUT(HDRP(PREV_BLKP(bp)), PACK(size, 0));
        bp = PREV_BLKP(bp);
    }
    else {              
        /*case 4*/                         
        delete(bp); 
        delete(PREV_BLKP(bp));
        delete(NEXT_BLKP(bp));
        size += GET_SIZE(HDRP(PREV_BLKP(bp))) + 
            GET_SIZE(FTRP(NEXT_BLKP(bp)));
        PUT(HDRP(PREV_BLKP(bp)), PACK(size, 0));
        PUT(FTRP(NEXT_BLKP(bp)), PACK(size, 0));
        bp = PREV_BLKP(bp);
    }
    add(bp, size);
    return bp;
}

static void *place(void *bp, size_t asize)
{
    size_t csize = GET_SIZE(HDRP(bp));   
    delete(bp);
    
    if ((csize - asize) >= (2*DSIZE)) { 
        PUT(HDRP(bp), PACK(asize, 1));
        PUT(FTRP(bp), PACK(asize, 1));
        PUT(HDRP(NEXT_BLKP(bp)), PACK(csize-asize, 0));
        PUT(FTRP(NEXT_BLKP(bp)), PACK(csize-asize, 0));
        add(NEXT_BLKP(bp), csize - asize);
    }
    else { 
        PUT(HDRP(bp), PACK(csize, 1));
        PUT(FTRP(bp), PACK(csize, 1));
    }
    return bp;
}

static void *add_helper(void *current, void *bp, size_t size) {
    //삽입 위치 찾음
    if (current == NULL || GET_SIZE(HDRP(current)) >= size) {
        SET_P(NEXT_P(bp), current);
        SET_P(PREV_P(bp), NULL);
        if (current != NULL) {
            SET_P(PREV_P(current), bp);
        }
        return bp;
    }
    
    void *next = NEXT_NODE(current);
    void *new_next = add_helper(next, bp, size);
    
    if (new_next != next) {
        SET_P(NEXT_P(current), new_next);
        if (new_next != NULL) {
            SET_P(PREV_P(new_next), current);
        }
    }
    
    return current;
}

static void add(void *bp, size_t size) {
    void **head = get_seg_head(get_list(size));
    *head = add_helper(*head, bp, size);
}




static void delete(void *bp) {
    size_t size = GET_SIZE(HDRP(bp));
    int c = get_list(size);
    void **head = get_seg_head(c);  // 헤드 포인터 가져오기

    void *next_bp = NEXT_NODE(bp);
    void *prev_bp = PREV_NODE(bp);

    if (next_bp != NULL) {
        SET_P(PREV_P(next_bp), prev_bp);
    }

    if (prev_bp != NULL) {
        SET_P(NEXT_P(prev_bp), next_bp);
    } else {
        *head = next_bp; 
    }
}

static void *find_fit(size_t asize)
{
    char *bp;
    size_t limitsize = asize;

    int idx = 0;
    while (idx < LISTNUM) {
        void **head = get_seg_head(idx);  // 헤드 포인터 가져오기
        
        if ((*head != NULL) && (limitsize <= 1) || (idx >= LISTNUM - 1)) {
            bp = *head;  
            while (bp != NULL) {
                if (asize <= GET_SIZE(HDRP(bp))) {
                    return bp; 
                }
                bp = NEXT_NODE(bp);
            }
        }
        limitsize >>= 1;
        idx++;
    }
    return NULL; 
}

void *mm_realloc(void *ptr, size_t size) {

    if (size == 0) {
        mm_free(ptr);
        return NULL;
    }

    if (ptr == NULL) {
        return mm_malloc(size);
    }

    size_t asize = (size <= DSIZE) ? 2 * DSIZE : DSIZE * ((size + DSIZE + (DSIZE - 1)) / DSIZE);
    size_t oldsize = GET_SIZE(HDRP(ptr));

    if (asize <= oldsize) {
        return ptr;
    }

    void *next_block = NEXT_BLKP(ptr);
    void *prev_block = PREV_BLKP(ptr);
    size_t next_avail = !GET_ALLOC(HDRP(next_block));
    size_t prev_avail = !GET_ALLOC(HDRP(prev_block));
    size_t next_size = GET_SIZE(HDRP(next_block));
    size_t prev_size = GET_SIZE(HDRP(prev_block));

    if (prev_avail && next_avail) {
        size_t combined_size = oldsize + prev_size + next_size;
        if (combined_size >= asize) {
            delete(prev_block);
            delete(next_block);
            PUT(HDRP(prev_block), PACK(combined_size, 1));
            PUT(FTRP(next_block), PACK(combined_size, 1));
            memmove(prev_block, ptr, oldsize);
            return prev_block;
        }
    }

    // 다음 블록
    if (next_avail && (oldsize + next_size >= asize)) {
        delete(next_block);
        PUT(HDRP(ptr), PACK(oldsize + next_size, 1));
        PUT(FTRP(ptr), PACK(oldsize + next_size, 1));
        return ptr;
    }

    // 전블럭
    if (prev_avail && (oldsize + prev_size >= asize)) {
        delete(prev_block);
        PUT(HDRP(prev_block), PACK(oldsize + prev_size, 1));
        PUT(FTRP(ptr), PACK(oldsize + prev_size, 1));
        memmove(prev_block, ptr, oldsize);
        return prev_block;
    }

    void *newptr = mm_malloc(size);
    if (newptr == NULL) return NULL;

    memcpy(newptr, ptr, (oldsize < size) ? oldsize : size);
    mm_free(ptr);
    return newptr;
}


static int get_list(size_t size) {
    int idx = 0;
    size_t s = size;

    while ((idx < LISTNUM - 1) && (size > 1)) {
        size = size / 2;
        idx++;
    }

    return idx;
}
