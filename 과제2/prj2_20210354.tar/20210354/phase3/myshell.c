/* $begin shellmain */
#include "myshell.h"
#include <errno.h>
#include <signal.h>
#define _POSIX_C_SOURCE 200809L

#define MAXARGS 128
#define MAX_JOBS 10

/* Function prototypes */
void eval(char *cmdline);
int parseline(char *buf, char **argv, int *pipe_count);
int builtin_command(char **argv);
int count_pipeline(char *);                            // pipe 의 개수를 세는 함수
void pipe_run(int pipe_count, int count, char **argv); // pipe 가 존재하는 경우 실행
void none_pipe_run(char **argv);                       // pipe 가 존재하지 않는 경우 실행

/*signal 관련 함수*/
volatile sig_atomic_t pid , fgpid=0;// foreground pid 설정 
int job_count = 0;
void delete_job(pid_t);

void sigint_handler(int);
void sigchld_handler(int);
void sigtstp_handler(int);
// void sigcont_handler(int); 
void add_job(pid_t, char, char **);

struct job
{
    pid_t pid;
    int job_id;
    int status;
    char job_cmd[MAXLINE];
};
struct job jobs[MAX_JOBS];

int main()
{
    char cmdline[MAXLINE]; /* Command line */

    /* signal 관련 변수. -> 완성안하면 에러나서 일단 보류*/
    Signal(SIGINT, sigint_handler); // ctrl z
    Signal(SIGCHLD, sigchld_handler);
    Signal(SIGTSTP, sigtstp_handler);
    // Signal(SIGCONT, sigcont_handler);

    for (int i = 0; i < MAX_JOBS; i++)
    {
        jobs[i].job_id = 0;
        jobs[i].pid = 0;
        jobs[i].status = 0;
    }

    while (1)
    {
        /* Read */
        printf("CSE4100-SP-P2> ");
        fgets(cmdline, MAXLINE, stdin);
        if (feof(stdin))
            exit(0);

        /* Evaluate */
        eval(cmdline);
    }
}
/* $end shellmain */

/* $begin eval */
/* eval - Evaluate a command line */
void eval(char *cmdline)
{
    char *argv[MAXARGS];    /* Argument list execve() */
    char buf[MAXLINE];      /* Holds modified command line */
    int bg;                 /* Should the job run in bg or fg? */
    pid_t pid;              /* Process id */
    int pipe_count = 0;     // pipe 의 개수를 count 해준다.
    char new_argv[MAXLINE]; // 전처리된 명령줄
    strcpy(buf, cmdline);

    /* signal 관련 변수*/
    sigset_t mask_one, mask_int, mask_stp, prev, mask_all;
    Sigemptyset(&mask_one);
    Sigaddset(&mask_one, SIGCHLD);
    sigemptyset(&mask_int);
    sigaddset(&mask_int, SIGINT);
    sigemptyset(&mask_stp);
    sigaddset(&mask_stp, SIGTSTP);

    bg = parseline(buf, argv, &pipe_count);

    if (argv[0] == NULL)
        return; /* Ignore empty lines */
    if (!builtin_command(argv))
    {
        sigprocmask(SIG_BLOCK, &mask_one, &prev); // race 를 피하기 위해 설정.

        // 자식 프로세스인 경우에만 실행되도록. . 자식에서는 signal 해제시킴.
        if ((pid = Fork()) == 0)
        {
            sigprocmask(SIG_SETMASK, &prev, NULL);
            setpgid(0, 0); // 그룹 설정

            if (pipe_count == 0) // pipe not exist . phase 1 과 동일하게 처리.
            {
                none_pipe_run(argv);
            }
            else if (pipe_count >= 1)
            {
                pipe_run(pipe_count, 0, argv);
            }
        }

        sigprocmask(SIG_SETMASK, &prev, NULL); // parent process 에서는 다시 복구.
        /* Parent waits for foreground job to terminate */
        if (!bg)
        {
            int status;
            fgpid = pid;
            if (waitpid(pid, &status, 0) < 0) // child process 가 돌아가는 동안 parent process 는 wait 해야함 (bg 가 아닐시)
            {
                unix_error("waitpid error in parents wait");
            }
            pid = 0;
        }
        else // when there is backgrount process!
        {
            printf("%d %s", pid, cmdline);
            add_job(pid, 1, argv); // status =1 -> 실행중.
        }
    }

    return;
}

/* If first arg is a builtin command, run it and return true */
int builtin_command(char **argv)
{
    if (!strcmp(argv[0], "quit") || !strcmp(argv[0], "exit")) /* quit command & exit */
        exit(0);
    if (!strcmp(argv[0], "&")) /* Ignore singleton & */
        return 1;

    if (!strcmp(argv[0], "cd")) /* cd - not builtin_Command */
    {                           // getenv 로 디렉토리 가져옴 . chdir 로 디렉토리 변경
        int status;
        // home 으로 가는 경우
        if (argv[1] == NULL || !strcmp(argv[1], "$HOME") || !strcmp(argv[1], "~"))
        {
            status = chdir(getenv("HOME"));
        }
        else
        {
            status = chdir(argv[1]);
        }

        return 1;
    }

    // jobs 명령어 역시 builtin_command임
    sigset_t mask_all;

    if (!strcmp(argv[0], "jobs"))
    {
        for (int i = 0; i < job_count; i++)
        {
            printf("[%d]", jobs[i].job_id);

            if (jobs[i].status == 1)
                printf(" Running                   ");
            else
                printf(" Stopped                   ");

            printf("%s\n", jobs[i].job_cmd);
        }
        return 1;
    }

    if (!strcmp(argv[0], "bg")) {
        if (argv[1] == NULL || argv[1][0] != '%') {
            printf("bg: argument error\n");
            return 1;
        }

        int job_cmd = atoi(&argv[1][1]);
        int found = 0;
        for (int i = 0; i < job_count; i++) {
            if (jobs[i].job_id == job_cmd) {
                found = 1;
                if (jobs[i].status == 0) { // 정지 상태이면
                    kill(-jobs[i].pid, SIGCONT);
                    jobs[i].status = 1;
                } else {
                    printf("running\n");
                }
                break;
            }
        }
        if (!found)
            printf("bg: %d: no such job\n", job_cmd);
        
        printf("[%d]+ stopped\n" , job_cmd);
        return 1;
    }


    if (!strcmp(argv[0], "fg")) {
        if (argv[1] == NULL || argv[1][0] != '%') {
            printf("fg: argument error\n");
            return 1;
        }
        int job_cmd = atoi(&argv[1][1]);
        int found = 0;
        for (int i = 0; i < job_count; i++) {
            if (jobs[i].status == 1) { // 어떻게 foreground 로 가져오지 .? 
                kill(-jobs[i].pid, SIGCONT);
                jobs[i].status = 0;
            } else {
                printf("running\n");
            }
            break;
        }
        if (!found)
            printf("bg: %d: no such job\n", job_cmd);
        return 1;

    }

    if (!strcmp(argv[0], "kill")) {
        if (argv[1] == NULL || argv[1][0] != '%') {
            printf("kill: argument error\n");
            return 1;
        }

        int job_cmd = atoi(&argv[1][1]);
        int found = 0;
        for (int i = 0; i < job_count; i++) {
            if (jobs[i].job_id == job_cmd) {
                kill(-jobs[i].pid , SIGKILL); // --> ? 어떻게 처리하지 
                found = 1;
                break;
            }
        }
        if (!found)
            printf("bg: %d: no such job\n", job_cmd);
        return 1;
    }


    return 0; /* Not a builtin command */
}
/* $end eval */

/*
    // echo 인 경우  ehco "content" {> or >>} {텍스트 파일이름}
    if (!strcmp(argv[0], "echo"))
    {
        return 1;
    }

*/

/* $begin parseline */
/* parseline - Parse the command line and build the argv array */
int parseline(char *buf, char **argv, int *pipe_count)
{
    int idx = 0;  // 인덱스
    int argc = 0; // 인자개수
    int bg;
    int start_token = 0;   // 토큰 시작.
    int flg = 0;           // (")quote flag
    int flg2 = 0;          // (')flag
    char new_buf[MAXLINE]; // quote 처리
    int new_idx = 0;       // quote 처리 인덱스

    buf[strlen(buf) - 1] = ' ';

    // 맨처음 공백 제거
    while (buf[idx] == ' ')
    {
        idx++;
    }

    while (buf[idx] != '\0')
    {
        // quote 에 따라서 상태 switch -> quote 자체는 인덱스에 들어가면 안됨 + (') 안에서는 무시
        if (buf[idx] == '"' && !flg2)
        {
            idx++;
            flg = !flg;
            continue;
        }

        if (buf[idx] == '\'' && !flg)
        {
            idx++;
            flg2 = !flg2;
            continue;
        }

        // quote 가 아닌 경우
        if (!flg && !flg2)
        {
            if (buf[idx] == '|')
            {
                (*pipe_count)++;
                if (new_idx > start_token)
                {
                    new_buf[new_idx] = '\0';
                    argv[argc] = &new_buf[start_token];
                    argc++;
                    new_idx++;
                }

                // pipe 문자 직접 추가.
                start_token = new_idx;
                new_buf[new_idx++] = '|';
                new_buf[new_idx++] = '\0';
                argv[argc++] = &new_buf[start_token];

                start_token = new_idx; // 다음 토큰 시작 위치 설정정
                idx++;                 // 파이프는 넘어감감

                // 공백 스킾
                while (buf[idx] == ' ')
                {
                    idx++;
                }

                continue;
            }

            if (buf[idx] == ' ')
            {
                if (new_idx > start_token)
                {
                    new_buf[new_idx] = '\0';
                    argv[argc++] = &new_buf[start_token];
                    new_idx++;
                }

                start_token = new_idx;

                // 공백 스킾
                while (buf[idx] == ' ')
                {
                    idx++;
                }

                continue;
            }
        }

        new_buf[new_idx++] = buf[idx++];
    }

    // 마지막 처리
    if (new_idx > start_token)
    {
        new_buf[new_idx] = '\0';
        argv[argc++] = &new_buf[start_token];
    }

    argv[argc] = NULL;
    if (argc == 0)
        return 1;

    // bg 처리
    /* Should the job run in the background? */
    if ((bg = (*argv[argc - 1] == '&')) != 0)
        argv[--argc] = NULL; // & 제거해서

    // bg 가 마지막 글자에 붙어 있는 경우도 처리하고자 함.
    char *last_char = argv[argc - 1];
    int len = strlen(last_char);
    if (last_char[len - 1] == '&')
    {
        bg = 1;
        last_char[len - 1] = '\0';
    }

    return bg;
}
/* $end parseline */
/* $begin count_pipeline */
/*
파싱 자체는 parseline 에서 해두었으니 우리는 | 의 개수를 세서 pipe의 길이(크기) 를 먼저 측정한다.
이후 | 의 개수를 가지고 동작하도록 진행.
*/
int count_pipeline(char *pipe_buf)
{

    int pipe_count = 0;
    for (int i = 0; pipe_buf[i] != '\0'; i++)
    {
        if (pipe_buf[i] == '|')
        {
            pipe_count++;
        }
    }
    return pipe_count;
}
/* $end count_pipeline */

/* $begin none pipe rum */
/* none_pipe_run - pipe 가 없을 경우 실행 ( phase 1 과 동일하게 작동.) */
void none_pipe_run(char **argv)
{
    char add_bin[30] = "/bin/"; // builtin_command : /bin/ls 와 같은 꼴이기 때문. -. excvp 사용하면됨.
    strncat(add_bin, argv[0], strlen(argv[0]));

    // quit . exit(0), & . ignore, other . run
    if (execve(add_bin, argv, environ) < 0)
    {
        // ex) /bin/ls ls -al &
        printf("%s: Command not found.\n", argv[0]);
        exit(0);
    }
}
/* $end none_pipe_run */

/* $begin pipeline */
/* pipe line 을 처리하면 된다.  recursive 하게 처리하고자 함.
pipe_run(int pipe_count = 총 몇개의 pipe 가 존재하는지 , int count = 현재 몇번째 pipe 인지 , argv)
*/
void pipe_run(int pipe_count, int count, char **argv)
{

    int fd[2];
    pid_t pid;
    char *command[MAXARGS];

    // base condition (마지막 명령어인 경우)
    if (count == pipe_count)
    {
        execvp(argv[0], argv);
        printf("Pipe Error : base comdition \n");
        exit(1);
    }

    if (pipe(fd) < 0)
    {
        printf("Pipe Error : pipe not exist\n");
        exit(1);
    }

    // 필요한 명령어를 command 에 옮겨준다 .
    int new_idx = 0;
    for (; argv[new_idx] != NULL && strcmp(argv[new_idx], "|") != 0; new_idx++)
    {
        command[new_idx] = argv[new_idx];
    }
    command[new_idx] = NULL;

    // 파이프 건너띄기
    if (argv[new_idx] != NULL && strcmp(argv[new_idx], "|") == 0)
        new_idx++;

    // 이후 사용할 커멘드를 tmp 에 옮겨 다음 fork 시에 사용.
    char *tmp[MAXARGS];
    int j = 0;
    while (argv[new_idx] != NULL)
    {
        tmp[j++] = argv[new_idx++];
    }
    tmp[j] = NULL; // NULL 종료

    // 자식프로세스인 경우.
    int status;
    if ((pid = fork()) == 0)
    {

        close(fd[0]);
        dup2(fd[1], STDOUT_FILENO);
        close(fd[1]);

        execvp(command[0], command);
        printf("command not found.\n");
        exit(1);
    }
    // 부모프로세스인 경우.
    else
    {
        close(fd[1]);
        dup2(fd[0], STDIN_FILENO);
        close(fd[0]);

        waitpid(pid, &status, 0); // 재귀적으로 호출되기 전에 부모프로세스는 wait

        pipe_run(pipe_count, count + 1, tmp); // reculsive function
    }
}

/* 기존 파싱함수
int parseline(char *buf, char **argv)
{
    char *delim; /* Points to first space delimiter
    int argc;    /* Number of args
    int bg;      /* Background job?

    buf[strlen(buf) - 1] = ' ';   /* Replace trailing '\n' with space
    while (*buf && (*buf == ' ')) /* Ignore leading spaces
        buf++;

    /* Build the argv list
    argc = 0;
    while ((delim = strchr(buf, ' ')))
    {
        argv[argc++] = buf;
        *delim = '\0';
        buf = delim + 1;
        while (*buf && (*buf == ' ')) /* Ignore spaces
            buf++;
    }

    argv[argc] = NULL;

    if (argc == 0) /* Ignore blank line
        return 1;

    /* Should the job run in the background?
    if ((bg = (*argv[argc - 1] == '&')) != 0)
        argv[--argc] = NULL;    // & 제거해서 argv 에 넣어줌

    return bg;
}
*/

/***************시그널 처리 (*********************/
void add_job(pid_t pid, char status, char **argv)
{
    jobs[job_count].pid = pid;
    jobs[job_count].status = 1;
    jobs[job_count].job_id = job_count + 1;
    jobs[job_count].job_cmd[0] = '\0'; //  중복으로 overwriting 되는걸 해결하기 위해 초기화

    for (int i = 0; argv[i] != NULL; i++)
    {
        strcat(jobs[job_count].job_cmd, argv[i]);
        if (argv[i + 1] != NULL)
            strcat(jobs[job_count].job_cmd, " ");
    }
    job_count++;
}

void delete_job(pid_t pid)
{
    for (int i = 0; i < job_count; i++)
    {
        if (jobs[i].pid == pid)
        {
            for (int j = i; j < job_count - 1; j++)
            {
                jobs[j] = jobs[j + 1];
                jobs[j].job_id--;
            }
            job_count--;
            break;
        }
    }
}

void sigchld_handler(int sig)
{
    int olderrno = errno;
    int status;
    sigset_t mask_all, prev_all;
    pid_t pid;

    Sigfillset(&mask_all); // 핸들러 수행 동안 다른 시그널을 모두 막는다.
    while ((pid = waitpid(-1, &status, WNOHANG)) > 0)
    {
        Sigprocmask(SIG_BLOCK, &mask_all, &prev_all);
        delete_job(pid);
        Sigprocmask(SIG_SETMASK, &prev_all, NULL);
    }

    if (pid < 0 && errno != ECHILD)
        Sio_error("sigchld waitpid error");
    errno = olderrno;
}

void sigint_handler(int sig)
{
    int olderrno = errno;

    sigset_t mask_all, prev;
    Sigfillset(&mask_all);
    Sigprocmask(SIG_BLOCK, &mask_all, &prev);

    if(fgpid!=0){
        kill(-fgpid,SIGINT);
    }

    Sigprocmask(SIG_SETMASK, &prev, NULL);

    olderrno = errno;
}

void sigtstp_handler(int sig)
{
    int olderrno = errno;
    sigset_t mask_all, prev;
    Sigfillset(&mask_all);
    Sigprocmask(SIG_BLOCK, &mask_all, &prev);

    if(fgpid!=0){
        kill(-fgpid,SIGTSTP);
    }

    Sigprocmask(SIG_SETMASK, &prev, NULL);

    errno = olderrno;
}