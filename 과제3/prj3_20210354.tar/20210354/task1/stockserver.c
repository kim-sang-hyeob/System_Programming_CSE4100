/*
 * echoserveri.c - An iterative echo server
 */
/* $begin echoserverimain */

// add for task3



//finish 




#include "csapp.h"
#include <signal.h>

#define MAX_MAX_BUF_SIZE 18000
#define MAX_NODE 1000
#define MAX_STOCKS 1000

void echo(int connfd);
int cnt_client = 0; // 클라이언트 개수

struct item *stock_order[MAX_NODE]; // 노드 순서 저장하기 위해서.

struct item
{
    int ID;         // id
    int left_stock; // 잔여주식
    int price;      // 가격
    int readcnt;
    struct item *left;
    struct item *right; // binary tree 로 연결
};
struct item *root = NULL;
struct item *order_list[MAX_STOCKS]; // 순서 저장을 위해서 .
int order_cnt = 0;

typedef struct
{
    int maxfd;
    fd_set read_set;
    fd_set ready_set;
    int nready;                  // ready_set 개수 (fd 개수임임)
    int maxi;                    // clientfd 상 최대 index
    int clientfd[FD_SETSIZE];    // active descriptor
    rio_t clientrio[FD_SETSIZE]; // RIO 버퍼
} pool;

void init_pool(int listenfd, pool *p)
{
    int i;
    p->maxi = -1;
    for (i = 0; i < FD_SETSIZE; i++)
        p->clientfd[i] = -1; // clientfd 다 -1 로 설정

    p->maxfd = listenfd;
    FD_ZERO(&p->read_set);
    FD_SET(listenfd, &p->read_set); // listenfd는 Active
}

void add_client(int connfd, pool *p)
{
    int i;
    p->nready--; // 작업 한번 했으니까 빼준다.

    for (i = 0; i < FD_SETSIZE; i++)
    {
        // 비어있는 경우에 삽입
        if (p->clientfd[i] < 0)
        {
            cnt_client++; // 클라이언트 개수 추가
            p->clientfd[i] = connfd;
            Rio_readinitb(&p->clientrio[i], connfd); // rio buffer 초기화

            FD_SET(connfd, &p->read_set); // read_Set 에 connfd 추가 -> 여기서 추가해주는게 맞음. (새로 descriptor 에서 복사하지 않으니까)

            if (connfd > p->maxfd) // 기존 fd 최대 값보다 큰 경우
                p->maxfd = connfd;
            if (i > p->maxi) // clientfd 값의 최대일 경우 (어디까지 반복할지 결정정)
                p->maxi = i;
            break;
        }
    }

    // 길이가 최대값을 넘은 경우 error 발생
    if (i == FD_SETSIZE)
        app_error("Error in add_client!\n");
}

// 왜바꿨는데 순서대로 안나오고 정렬하지 ? ** 다시 수정할것 ** --> 완

void show(int connfd, struct item *it)
{
    char cmd2[MAXLINE] = "";
    int len = 0;

    for (int i = 0; i < order_cnt; i++)
    {
        struct item *it_i = order_list[i];

        int tmp = snprintf(cmd2 + len, MAXLINE - len, "%d %d %d\n", it_i->ID, it_i->left_stock, it_i->price);
        len += tmp; // 길이 갱신.
    }

    Rio_writen(connfd, cmd2, MAXLINE);
}

// id 를 찾는다.
struct item *find_item(struct item *root, int id)
{
    if (!root)
        return NULL;
    if (id < root->ID)
        return find_item(root->left, id);
    if (id > root->ID)
        return find_item(root->right, id);
    return root;
}

void buy(int connfd, int id, int cnt)
{

    char cmd2[MAXLINE] = "";
    struct item *it = find_item(root, id);

    if (it == NULL)
    {
        snprintf(cmd2, MAXLINE, "[buy] error: no stock here\n");
        Rio_writen(connfd, cmd2, MAXLINE);
        return;
    }

    if (it->left_stock < cnt)
    {
        snprintf(cmd2, MAXLINE, "Not enough left stocks\n");
    }
    else
    {
        it->left_stock -= cnt;
        snprintf(cmd2, MAXLINE, "[buy] success\n");
    }

    Rio_writen(connfd, cmd2, MAXLINE);
}

// sell 은 실패가 없다고 가정.
void sell(int connfd, int id, int cnt)
{
    char cmd2[MAXLINE] = "";
    struct item *it = find_item(root, id);

    if (it == NULL)
    {
        snprintf(cmd2, MAXLINE, "sell error : not in fd\n");
        Rio_writen(connfd, cmd2, MAXLINE);
        return;
    }

    it->left_stock += cnt;
    snprintf(cmd2, MAXLINE, "[sell] success\n");

    Rio_writen(connfd, cmd2, MAXLINE);
}

void save()
{
    FILE *fp = fopen("stock.txt", "w");
    if (!fp)
    {
        perror("fopen");
        return;
    }
    for (int i = 0; i < order_cnt; i++)
    {
        struct item *it = order_list[i];
        fprintf(fp, "%d %d %d\n", it->ID, it->left_stock, it->price);
    }

    printf("save all!\n");
    fclose(fp);
}

void sell_stock(int connfd, int id, int cnt)
{
    struct item *it = find_item(root, id);

    if (!it)
    {
        Rio_writen(connfd, "no available sell\n", 18);
        return;
    }
    it->left_stock += cnt;
    Rio_writen(connfd, "[sell] success\n", 15);
}

void check_client(pool *p)
{
    int i, connfd, n, id, cnt;
    char buf[MAXLINE];
    char cmd[MAXLINE];
    rio_t *rio;

    for (i = 0; (i <= p->maxi) && (p->nready > 0); i++)
    {
        connfd = p->clientfd[i];
        rio = &p->clientrio[i];

        if (connfd > 0 && FD_ISSET(connfd, &p->ready_set))
        {
            p->nready--;

            if ((n = Rio_readlineb(rio, buf, MAXLINE)) <= 0)
            {
                printf("**exit : fd %d ! \n", connfd);

                Close(connfd);
                FD_CLR(connfd, &p->read_set);
                p->clientfd[i] = -1;
                cnt_client--;
                if (cnt_client == 0)
                    save();
                continue;
            }

            buf[strlen(buf) - 1] = '\0'; // 개행 제거
            printf("server received fd : %d , command : %s \n", connfd, buf);
            sscanf(buf, "%s", cmd);

            if (strcmp(cmd, "show") == 0)
            {
                show(connfd, root);
            }
            else if (strcmp(cmd, "exit") == 0)
            {
                char cmd2[MAXLINE] = "";
                snprintf(cmd2, MAXLINE, "exit fd : %d\n", connfd);
                Rio_writen(connfd, cmd2, MAXLINE);

                printf("exit : fd(%d)\n", connfd);
                Close(connfd);
                FD_CLR(connfd, &p->read_set);
                p->clientfd[i] = -1;
                cnt_client--; // 하나 닫았으니까
                if (cnt_client == 0)
                {
                    save();
                }
                continue;
            }
            else
            {
                if (sscanf(buf, "%s %d %d", cmd, &id, &cnt) == 3)
                {
                    if (strcmp(cmd, "buy") == 0)
                    {
                        buy(connfd, id, cnt);
                    }
                    else if (strcmp(cmd, "sell") == 0)
                    {
                        sell(connfd, id, cnt);
                    }
                }
                else
                {
                    strcpy(buf, "Invalid command\n");
                }
            }
        }
    }
}

/* bianry tree insert -> ID 를 기준으로 왼쪽 (작음) / 오른쪽(큼) */
struct item *insert(struct item *root, struct item *leaf)
{
    if (root == NULL)
    {
        return leaf;
    }
    // leaf 가 더 작은경우
    if (root->ID > leaf->ID)
    {
        root->left = insert(root->left, leaf);
    }
    // 큰 경우우
    else
    {
        root->right = insert(root->right, leaf);
    }
    return root;
}

void free_tree(struct item *node)
{
    if (!node)
        return;
    // 순회하면서 free 시켜줌
    free_tree(node->left);
    free_tree(node->right);
    free(node);
}

void sigint_handler(int sig)
{
    printf("signit_handler\n");
    save();
    free_tree(root);
    exit(0);
}

int main(int argc, char **argv)
{
    int listenfd, connfd;
    socklen_t clientlen;
    struct sockaddr_storage clientaddr; /* Enough space for any address */ // line:netp:echoserveri:sockaddrstorage
    static pool pool;
    char client_hostname[MAXLINE], client_port[MAXLINE];

    Signal(SIGINT, sigint_handler);

    if (argc != 2)
    {
        fprintf(stderr, "usage: %s <port>\n", argv[0]);
        exit(0);
    }

    /* 주식 관리 테이블 메모리 적재 (stock.txt 받아오기)*/
    FILE *fp = fopen("stock.txt", "r");
    if (!fp)
    {
        perror("file open error");
        exit(0);
    }

    int id, price, left_stock;
    while (fscanf(fp, "%d %d %d", &id, &left_stock, &price) == 3)
    {
        struct item *it = malloc(sizeof(struct item));
        it->ID = id;
        it->left_stock = left_stock;
        it->price = price;
        it->readcnt = 0;
        it->left = NULL;
        it->right = NULL; // 아직 연결 X

        if (root == NULL)
            root = it;
        else
            root = insert(root, it); // bianry_tree 에 연결

        order_list[order_cnt++] = it; // 실패 없다고 가정함. -> 입/출력시 순서 저장하기 위함.
    }
    fclose(fp);
    /* finish */

    listenfd = Open_listenfd(argv[1]);
    init_pool(listenfd, &pool);

    while (1)
    {
        pool.ready_set = pool.read_set;
        pool.nready = Select(pool.maxfd + 1, &pool.ready_set, NULL, NULL, NULL); // select( 최대 fd 값 , ready_Set , ... )

        // listen 하는 경우
        if (FD_ISSET(listenfd, &pool.ready_set))
        {
            clientlen = sizeof(struct sockaddr_storage);
            connfd = Accept(listenfd, (SA *)&clientaddr, &clientlen); // accept 해주고
            add_client(connfd, &pool);                                // 작업 추가되었다고 표시해준다.
            Getnameinfo((SA *)&clientaddr, clientlen, client_hostname, MAXLINE,
                        client_port, MAXLINE, 0);
            printf("Connected to (%s , %s)\n", client_hostname, client_port);
        }

        check_client(&pool); // 연결되어있는 connfd 들을 수행
    }
    exit(0);
}
/* $end echoserverimain */
