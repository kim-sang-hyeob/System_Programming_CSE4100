/*
 * echoservert.c - A concurrent echo server using threads
 */
/* $begin echoservertmain */
#include "csapp.h"
#include <signal.h>
#define NTHREADS 100
#define SBUFSIZE 100
#define MAX_STOCKS 1000

typedef struct item
{
	int ID;
	int left_stock;
	int price;
	int readcnt;
	sem_t mut; /* protects accesses to buf */
	sem_t wrt; //  preservation write
	struct item *left;
	struct item *right;
} item;

item *root = NULL;

typedef struct
{
	int *buf;			/* buffer array */
	int n;				/* maximum number of slots */
	int front;			/* first item */
	int rear;			/* last item */
	sem_t mutex;		/* protects accesses to buf */
	sem_t slots, items; // slots = 처리할 수 있는 갯수(빈자리) n개  , items = 처리중인 갯수 0 개 시작
} sbuf_t;

sbuf_t sbuf; // Connected Descriptor를 Item으로 하는 Shared Buffer
sem_t u, p;
item *order_list[MAX_STOCKS]; // 순서대로 명령어 출력하기 위함.
int order_cnt = 0;
sem_t file_mutex; // 마무리하고 파일 쓰는 경우에도 mutex 걸어서 안전하게.

sem_t mutex; // Mutual Exclusion을 위한 Mutex (Semaphore)
void *thread(void *vargp);
void buf_init(sbuf_t *, int); // buf 초기화 설정

// SBUF FUNCITON
void sbuf_init(sbuf_t *sp, int n);		// Shared Buffer Initialization
void sbuf_deinit(sbuf_t *sp);			// Shared Buffer Clear
void sbuf_insert(sbuf_t *sp, int item); // Buffer Insertion (Produce)
int sbuf_remove(sbuf_t *sp);			// Buffer Removement (Consume)

// run_job func
void run_job(int connfd);
void exit_f(int, item *);
void sell(int, int, int);
void buy(int, int, int);
void show(int, item *, char *);
item *insert(item *, item *);

// exit 를 위한 변수모음
int cnt_client = 0;
sem_t cnt_mut;
void save();

// 최종 종료시 free 시켜주기 위함함
void sigint_handler(int sig);

// main = main thread
int main(int argc, char **argv)
{
	int i, listenfd, connfd;
	socklen_t clientlen;
	struct sockaddr_storage clientaddr;
	pthread_t tid;
	char client_hostname[MAXLINE], client_port[MAXLINE];

	if (argc != 2)
	{
		fprintf(stderr, "usage: %s <port>\n", argv[0]);
		exit(0);
	}

	listenfd = Open_listenfd(argv[1]);
	buf_init(&sbuf, SBUFSIZE); // sbuffer 초기화

	Sem_init(&cnt_mut, 0, 1); // save 하는 경우 safe 하도록 설정

	for (i = 0; i < NTHREADS; i++)				  // Worker thread 만듬
		Pthread_create(&tid, NULL, thread, NULL); // consumer 생성성

	while (1)
	{
		clientlen = sizeof(struct sockaddr_storage);
		connfd = Accept(listenfd, (SA *)&clientaddr, &clientlen); // Request 오면

		// exit 를 위해서 cnt_client 해줌. 이때도 thread safe 하게 처리하고자함./
		P(&cnt_mut);
		cnt_client++;
		V(&cnt_mut);

		sbuf_insert(&sbuf, connfd); // 버퍼에 삽입
		Getnameinfo((SA *)&clientaddr, clientlen, client_hostname, MAXLINE, client_port, MAXLINE, 0);
		printf("Connected to (%s , %s)\n", client_hostname, client_port);
	}
}

void *thread(void *vargp)
{
	Pthread_detach(pthread_self()); // Reapin.

	while (1)
	{
		int connfd = sbuf_remove(&sbuf);
		run_job(connfd);
		Close(connfd);

		// thread 에서 job 이 끝난경우 (exit)
		P(&cnt_mut);
		cnt_client--;
		int empty = (cnt_client == 0);
		V(&cnt_mut);

		// 만약 다 종료된 경우 save()
		if (empty)
		{
			printf("all exit! \n save tree\n");
			save();
		}
	}
}

void sigint_handler(int sig)
{

	save();
	printf("exit server and save\n");

	sbuf_deinit(&sbuf);
	sem_destroy(&cnt_mut);

	for (int i = 0; i < order_cnt; i++)
	{
		sem_destroy(&order_list[i]->mut);
		sem_destroy(&order_list[i]->wrt);
		free(order_list[i]);
	}

	exit(0);
}

// peer thread 가 처리하는 영역
void run_job(int connfd)
{

	int id, cnt;
	char buf[MAXLINE];
	char cmd[MAXLINE];
	rio_t rio;

	Rio_readinitb(&rio, connfd);

	while (Rio_readlineb(&rio, buf, MAXLINE) > 0)
	{
		sscanf(buf, "%s", cmd);
		printf("server received fd : %d , command : %s \n", connfd, buf);
		if (strcmp(cmd, "show") == 0)
			show(connfd, root, buf);
		else if (strcmp(cmd, "exit") == 0)
		{
			printf("exit ! fd : %d\n", connfd);
			exit_f(connfd, root);
			break;
		}
		else
		{
			if (sscanf(buf, "%s %d %d", cmd, &id, &cnt) == 3)
			{
				if (strcmp(cmd, "buy") == 0)
				{
					buy(connfd, id, cnt);
				}
				else if (strcmp(cmd, "sell") == 0)
				{
					sell(connfd, id, cnt);
				}
			}
		}
	}

	printf("**exit fd : %d \n", connfd); // 추가 .
}

void buf_init(sbuf_t *sp, int n)
{

	FILE *fp = fopen("stock.txt", "r");
	if (!fp)
	{
		perror("file open error");
		exit(0);
	}

	int id, price, left_stock;
	while (fscanf(fp, "%d %d %d", &id, &left_stock, &price) == 3)
	{
		item *it = malloc(sizeof(item));
		it->ID = id;
		it->left_stock = left_stock;
		it->price = price;
		it->readcnt = 0;
		it->left = NULL;
		it->right = NULL;		  // 아직 연결 X
		Sem_init(&it->mut, 0, 1); // read-write 보호
		Sem_init(&it->wrt, 0, 1); // write 하는 경우에도 추가로
		if (root == NULL)
			root = it;
		else
			root = insert(root, it); // bianry_tree 에 연결

		order_list[order_cnt++] = it; // 실패 없다고 가정함.
	}
	fclose(fp);

	// 기본제공 코드 활용
	sp->buf = Calloc(n, sizeof(int));
	sp->n = n;
	sp->front = sp->rear = 0;
	Sem_init(&sp->mutex, 0, 1);
	Sem_init(&sp->slots, 0, n);
	Sem_init(&sp->items, 0, 0);
}

void sbuf_init(sbuf_t *sp, int n)
{
	sp->buf = Calloc(n, sizeof(int));
	sp->n = n;
	sp->front = sp->rear = 0;
	Sem_init(&sp->mutex, 0, 1);
	Sem_init(&sp->slots, 0, n);
	Sem_init(&sp->items, 0, 0);
}

void sbuf_deinit(sbuf_t *sp)
{
	Free(sp->buf);

	sem_destroy(&sp->mutex);
	sem_destroy(&sp->slots);
	sem_destroy(&sp->items);
}

void sbuf_insert(sbuf_t *sp, int item)
{
	P(&sp->slots);
	P(&sp->mutex);
	sp->buf[(++(sp->rear)) % (sp->n)] = item;
	V(&sp->mutex);
	V(&sp->items);
}

// Shared Buffer의 front에서 item을 제거하고 리턴
int sbuf_remove(sbuf_t *sp)
{
	int item;
	P(&sp->items);
	P(&sp->mutex);
	item = sp->buf[(++(sp->front)) % (sp->n)];
	V(&sp->mutex);
	V(&sp->slots);

	return item;
}

void show(int connfd, item *it, char *buf)
{

	if (it == NULL)
	{
		printf("empty tree\n");
		return;
	}

	char cmd2[MAXLINE] = "";
	int len = 0;

	for (int i = 0; i < order_cnt; i++)
	{
		item *it_i = order_list[i];

		// read-write 문제 해결하기 위함.
		P(&it_i->mut);
		it_i->readcnt++;
		if (it_i->readcnt == 1)
			P(&it_i->wrt);
		V(&it_i->mut);

		int tmp = snprintf(cmd2 + len, MAXLINE - len,
						   "%d %d %d\n",
						   it_i->ID, it_i->left_stock, it_i->price);
		len += tmp;

		P(&it_i->mut);
		it_i->readcnt--;
		if (it_i->readcnt == 0)
			V(&it_i->wrt);
		V(&it_i->mut);
	}
	// 모아서 한꺼번에 출력 - multiclient 코드에서는 이렇게 해야함.
	Rio_writen(connfd, cmd2, MAXLINE);
}

void exit_f(int connfd, item *root)
{
	char cmd2[MAXLINE] = "";
	snprintf(cmd2, MAXLINE, "exit fd : %d\n", connfd);
	printf("exit fd : %d\n", connfd);
	Rio_writen(connfd, cmd2, MAXLINE);
	return;
}

item *find_item(item *root, int id)
{
	if (!root)
		return NULL;
	if (id < root->ID)
		return find_item(root->left, id);
	if (id > root->ID)
		return find_item(root->right, id);
	return root;
}

// sell 은 절대 실패하지 않는다.
void sell(int connfd, int id, int cnt)
{
	char cmd2[MAXLINE] = "";
	item *it = find_item(root, id);
	char *success = "[sell] success\n";

	// 그래도 혹시모르니까 ...?
	if (it == NULL)
	{
		printf("sell error : not in text file\n");
		return;
	}

	// write - race 생기지 않도록 p v 활용함.
	P(&it->wrt);

	it->left_stock += cnt;
	snprintf(cmd2, MAXLINE, "%s", success);

	V(&it->wrt);

	Rio_writen(connfd, cmd2, MAXLINE);
}

void buy(int connfd, int id, int cnt)
{
	char cmd2[MAXLINE] = "";
	item *it = find_item(root, id);
	char *not_left = "Not enough left stocks\n";
	char *success = "[buy] success\n";

	if (it == NULL)
	{
		snprintf(cmd2, MAXLINE, "[buy] error: no stock here\n");
		Rio_writen(connfd, cmd2, MAXLINE);
		return;
	}

	// write - race 생기지 않도록 p v 활용함.
	P(&it->wrt);
	if (it->left_stock < cnt)
	{
		snprintf(cmd2, MAXLINE, "%s", not_left);
	}
	else
	{
		it->left_stock -= cnt;
		snprintf(cmd2, MAXLINE, "%s", success);
	}
	V(&it->wrt);

	Rio_writen(connfd, cmd2, MAXLINE);
}

item *insert(struct item *root, struct item *leaf)
{
	if (root == NULL)
	{
		return leaf;
	}
	// leaf 가 더 작은경우
	if (root->ID > leaf->ID)
	{
		root->left = insert(root->left, leaf);
	}
	// 큰 경우우
	else
	{
		root->right = insert(root->right, leaf);
	}
	return root;
}

// 파일 세이브 하도록
void save()
{
	FILE *fp = fopen("stock.txt", "w");
	if (!fp)
	{
		perror("fopen");
		return;
	}

	// 리스트 돌면서 순서대로 저장하도록 하자.
	for (int i = 0; i < order_cnt; i++)
	{
		item *it = order_list[i];

		P(&it->wrt);
		fprintf(fp, "%d %d %d\n", it->ID, it->left_stock, it->price);
		V(&it->wrt);
	}

	fclose(fp);
}